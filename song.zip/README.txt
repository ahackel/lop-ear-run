Lop Hop: a song for the Stardrift engine (https://github.com/ahackel/stardrift-engine),
with the recordings it plays (hat_closed, hat_open, cymbal).

In a web game, the zip as it is:

  import { StardriftPlayer } from 'stardrift-engine';
  const music = new StardriftPlayer();
  await music.init();                        // after a click or a key (browsers start audio only then)
  await music.loadUrl('music/lop-hop.zip');
  music.play();
  music.setMood('menu');                     // its moods: menu, highscore, relaxed, wonder, exploring, tension, danger, action, power
  music.sting('go');                         // its stingers: go, jump, reward, bump, smash, chased, escape, dusk, dawn, record, discovery, alert, fanfare, power, powerdown

Unzipped into music/lop-hop/, the folder works too:

  await music.init({ library: 'music/lop-hop/library/' });
  await music.loadUrl('music/lop-hop/song.json');

The recordings (library/) are CC0 (public domain): see library/LICENSE.
